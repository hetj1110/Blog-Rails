require '/home/thinkbiz/.rvm/rubies/ruby-3.0.0/lib/ruby/gems/3.0.0/gems/gem-wrappers-1.4.0/lib/rubygems_plugin.rb'
