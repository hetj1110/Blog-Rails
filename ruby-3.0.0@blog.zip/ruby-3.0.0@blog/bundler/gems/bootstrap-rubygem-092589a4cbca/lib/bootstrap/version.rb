# frozen_string_literal: true

module Bootstrap
  VERSION       = '5.2.3'
  BOOTSTRAP_SHA = 'cb021439c683d9805e2864c58095b92d405e9b11'
end
