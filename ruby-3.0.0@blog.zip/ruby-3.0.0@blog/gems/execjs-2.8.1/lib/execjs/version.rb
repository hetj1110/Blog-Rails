module ExecJS
  VERSION = "2.8.1"
end
