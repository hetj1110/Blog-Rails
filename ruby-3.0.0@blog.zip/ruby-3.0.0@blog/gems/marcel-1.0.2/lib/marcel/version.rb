module Marcel
  VERSION = "1.0.2"
end
