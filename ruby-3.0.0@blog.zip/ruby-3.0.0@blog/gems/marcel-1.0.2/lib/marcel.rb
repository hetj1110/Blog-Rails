module Marcel
  require "marcel/version"
  require "marcel/magic"
  require "marcel/mime_type"
end
