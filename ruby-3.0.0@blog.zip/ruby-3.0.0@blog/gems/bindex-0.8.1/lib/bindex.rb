require_relative "skiptrace"

# Keep backwards compatibility with the previous name.
Bindex = Skiptrace
