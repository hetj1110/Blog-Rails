module Skiptrace
  VERSION = "0.8.1"
end
