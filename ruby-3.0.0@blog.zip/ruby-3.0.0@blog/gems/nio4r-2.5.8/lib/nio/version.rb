# frozen_string_literal: true

module NIO
  VERSION = "2.5.8"
end
