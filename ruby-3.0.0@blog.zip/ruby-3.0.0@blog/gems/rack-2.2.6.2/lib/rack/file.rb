# frozen_string_literal: true

require_relative 'files'

module Rack
  File = Files
end
